package com.example.dlei.tit;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class Act_criar_conta extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.act_criar_conta);
    }

    public void ir_para(View view){
        Intent it = new Intent(getApplicationContext(), Act_Criandoconta1.class);
        startActivity(it);
    }
}
